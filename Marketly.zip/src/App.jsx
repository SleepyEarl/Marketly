import { useMemo, useState } from 'react';
import {
  Search,
  ShoppingCart,
  UserRound,
  ArrowRight,
  ChevronRight,
  Heart,
  Star,
  Zap,
  Package,
  ShieldCheck,
  Truck,
  Menu,
  X,
  Minus,
  Plus,
  Trash2,
  ShoppingBag,
} from 'lucide-react';
import './index.css';

const products = [
  {
    id: 1,
    name: 'Wireless Headphones',
    category: 'Electronics',
    price: 899,
    oldPrice: 1299,
    rating: 4.8,
    reviews: 124,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=700',
  },
  {
    id: 2,
    name: 'Classic Sneakers',
    category: 'Fashion',
    price: 1499,
    oldPrice: 1899,
    rating: 4.9,
    reviews: 86,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=700',
  },
  {
    id: 3,
    name: 'Minimal Desk Lamp',
    category: 'Home & Living',
    price: 650,
    oldPrice: 850,
    rating: 4.7,
    reviews: 52,
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed057f782c?w=700',
  },
  {
    id: 4,
    name: 'Mechanical Keyboard',
    category: 'Electronics',
    price: 1899,
    oldPrice: 2299,
    rating: 4.9,
    reviews: 103,
    image: 'https://images.unsplash.com/photo-1595225476474-87563907a212?w=700',
  },
  {
    id: 5,
    name: 'Everyday Backpack',
    category: 'Fashion',
    price: 999,
    oldPrice: 1399,
    rating: 4.6,
    reviews: 71,
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=700',
  },
  {
    id: 6,
    name: 'Classic Wristwatch',
    category: 'Accessories',
    price: 1250,
    oldPrice: 1599,
    rating: 4.8,
    reviews: 94,
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?w=700',
  },
  {
    id: 7,
    name: 'Ceramic Coffee Mug',
    category: 'Home & Living',
    price: 299,
    oldPrice: 399,
    rating: 4.7,
    reviews: 43,
    image: 'https://images.unsplash.com/photo-1514228742587-6b1558fcca3d?w=700',
  },
  {
    id: 8,
    name: 'Portable Speaker',
    category: 'Electronics',
    price: 799,
    oldPrice: 1099,
    rating: 4.8,
    reviews: 67,
    image: 'https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=700',
  },
];

const categories = [
  { name: 'Electronics', icon: '⌁', description: 'Tech essentials' },
  { name: 'Fashion', icon: '◈', description: 'Everyday style' },
  { name: 'Home & Living', icon: '⌂', description: 'Make it yours' },
  { name: 'Accessories', icon: '◇', description: 'Finishing touches' },
];

const money = (amount) =>
  '₱' +
  amount.toLocaleString('en-PH', {
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

function App() {
  const [cart, setCart] = useState([]);
  const [search, setSearch] = useState('');
  const [activeCategory, setActiveCategory] = useState('All');
  const [favorites, setFavorites] = useState([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [orderComplete, setOrderComplete] = useState(false);
  const [completedOrder, setCompletedOrder] = useState(null);

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);

  const cartTotal = cart.reduce(
    (total, item) => total + item.price * item.quantity,
    0
  );

  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      const matchesSearch = product.name
        .toLowerCase()
        .includes(search.toLowerCase());

      const matchesCategory =
        activeCategory === 'All' || product.category === activeCategory;

      return matchesSearch && matchesCategory;
    });
  }, [search, activeCategory]);

  const addToCart = (product) => {
    setCart((current) => {
      const existing = current.find((item) => item.id === product.id);

      if (existing) {
        return current.map((item) =>
          item.id === product.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      }

      return [...current, { ...product, quantity: 1 }];
    });

    setCartOpen(true);
  };

  const updateQuantity = (id, amount) => {
    setCart((current) =>
      current
        .map((item) =>
          item.id === id ? { ...item, quantity: item.quantity + amount } : item
        )
        .filter((item) => item.quantity > 0)
    );
  };

  const removeFromCart = (id) => {
    setCart((current) => current.filter((item) => item.id !== id));
  };

  const toggleFavorite = (id) => {
    setFavorites((current) =>
      current.includes(id)
        ? current.filter((item) => item !== id)
        : [...current, id]
    );
  };

  const placeOrder = (event) => {
    event.preventDefault();

    if (cart.length === 0) return;

    const form = new FormData(event.currentTarget);

    const order = {
      orderNumber: 'MKT-' + Date.now().toString().slice(-7),
      date: new Date().toLocaleDateString('en-PH'),
      name: form.get('fullname'),
      email: form.get('email'),
      phone: form.get('phone'),
      address: form.get('address'),
      postalCode: form.get('postal'),
      items: [...cart],
      total: cartTotal,
    };

    setCompletedOrder(order);
    setCart([]);
    setCheckoutOpen(false);
    setOrderComplete(true);
  };

  return (
    <div className="app">
      {/* ANNOUNCEMENT */}
      <div className="announcement">
        <span>MARKETLY EVERYDAY DEALS</span>
        <span>
          Discover something worth having. <ArrowRight size={13} />
        </span>
      </div>

      {/* NAVIGATION */}
      <header className="navbar">
        <a href="#home" className="brand">
          <span className="brand-icon">M</span>
          <span>
            MARKETLY<span className="brand-dot">.</span>
          </span>
        </a>

        <nav className="nav-links">
          <a href="#home" className="active">
            Home
          </a>
          <a href="#categories">Categories</a>
          <a href="#products">Shop</a>
          <a href="#deals">Deals</a>
        </nav>

        <div className="nav-actions">
          <label className="search-box">
            <Search size={17} />
            <input
              type="text"
              placeholder="Search products..."
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setActiveCategory('All');
              }}
            />
          </label>

          <button className="icon-button" aria-label="Account">
            <UserRound size={20} />
          </button>

          <button
            className="icon-button cart-button"
            aria-label="Shopping cart"
            onClick={() => setCartOpen(true)}
          >
            <ShoppingCart size={21} />
            {cartCount > 0 && <span className="cart-count">{cartCount}</span>}
          </button>

          <button className="mobile-menu" aria-label="Menu">
            <Menu />
          </button>
        </div>
      </header>

      <main>
        {/* HERO */}
        <section className="hero" id="home">
          <div className="hero-content">
            <div className="hero-tag">
              <Zap size={14} /> YOUR EVERYDAY MARKETPLACE
            </div>

            <h1>
              Find what you need.
              <br />
              <span>Love what you get.</span>
            </h1>

            <p>
              From everyday essentials to things you didn't know you needed.
              Discover products made for your everyday life.
            </p>

            <div className="hero-buttons">
              <a href="#products" className="primary-button">
                Explore products <ArrowRight size={17} />
              </a>
              <a href="#categories" className="secondary-button">
                Browse categories
              </a>
            </div>

            <div className="hero-trust">
              <span>
                <ShieldCheck size={16} /> Quality picks
              </span>
              <span>
                <Truck size={16} /> Convenient shopping
              </span>
            </div>
          </div>

          <div className="hero-visual">
            <div className="hero-image-wrap">
              <img
                src="https://images.unsplash.com/photo-1607082349566-187342175e2f?w=1100"
                alt="Shopping bags and packages"
              />
            </div>

            <div className="floating-card">
              <div className="floating-icon">
                <Package size={20} />
              </div>
              <div>
                <strong>Good finds await.</strong>
                <span>Explore the collection</span>
              </div>
            </div>

            <div className="hero-decoration"></div>
          </div>
        </section>

        {/* BENEFITS */}
        <section className="benefits">
          <div>
            <Truck />
            <span>
              <strong>Convenient shopping</strong>
              <small>Shop from anywhere</small>
            </span>
          </div>
          <div>
            <ShieldCheck />
            <span>
              <strong>Quality selections</strong>
              <small>Products worth exploring</small>
            </span>
          </div>
          <div>
            <Package />
            <span>
              <strong>Easy ordering</strong>
              <small>A smoother way to shop</small>
            </span>
          </div>
        </section>

        {/* CATEGORIES */}
        <section className="section categories-section" id="categories">
          <div className="section-heading">
            <div>
              <span className="eyebrow">EXPLORE OUR COLLECTION</span>
              <h2>Shop by category</h2>
              <p>Find your next favorite, all in one place.</p>
            </div>

            <a href="#products" className="text-link">
              View all products <ArrowRight size={16} />
            </a>
          </div>

          <div className="category-grid">
            {categories.map((category) => (
              <button
                className={`category-card ${
                  activeCategory === category.name ? 'selected' : ''
                }`}
                key={category.name}
                onClick={() => {
                  setActiveCategory(category.name);
                  document.getElementById('products')?.scrollIntoView({
                    behavior: 'smooth',
                  });
                }}
              >
                <span className="category-icon">{category.icon}</span>
                <span className="category-name">{category.name}</span>
                <span className="category-description">
                  {category.description}
                </span>
                <ChevronRight className="category-arrow" size={18} />
              </button>
            ))}
          </div>
        </section>

        {/* PRODUCTS */}
        <section className="section products-section" id="products">
          <div className="section-heading">
            <div>
              <span className="eyebrow">HANDPICKED FOR YOU</span>
              <h2>Featured products</h2>
              <p>Popular finds worth checking out.</p>
            </div>

            <a
              href="#products"
              className="text-link"
              onClick={() => setActiveCategory('All')}
            >
              View all products <ArrowRight size={16} />
            </a>
          </div>

          <div className="filter-row">
            {['All', ...categories.map((category) => category.name)].map(
              (category) => (
                <button
                  key={category}
                  className={`filter-chip ${
                    activeCategory === category ? 'active' : ''
                  }`}
                  onClick={() => setActiveCategory(category)}
                >
                  {category}
                </button>
              )
            )}
          </div>

          <div className="product-grid">
            {filteredProducts.map((product) => (
              <article className="product-card" key={product.id}>
                <div className="product-image">
                  <img src={product.image} alt={product.name} />

                  <span className="sale-label">SPECIAL PRICE</span>

                  <button
                    className={`favorite-button ${
                      favorites.includes(product.id) ? 'favorited' : ''
                    }`}
                    onClick={() => toggleFavorite(product.id)}
                    aria-label="Toggle favorite"
                  >
                    <Heart
                      size={18}
                      fill={
                        favorites.includes(product.id) ? 'currentColor' : 'none'
                      }
                    />
                  </button>

                  <button
                    className="quick-add"
                    onClick={() => addToCart(product)}
                  >
                    Add to cart <ShoppingCart size={15} />
                  </button>
                </div>

                <div className="product-info">
                  <span className="product-category">{product.category}</span>
                  <h3>{product.name}</h3>

                  <div className="product-rating">
                    <Star size={14} fill="currentColor" />
                    {product.rating}
                    <span>({product.reviews} reviews)</span>
                  </div>

                  <div className="product-price">
                    <strong>{money(product.price)}</strong>
                    <del>{money(product.oldPrice)}</del>
                  </div>
                </div>
              </article>
            ))}
          </div>

          {filteredProducts.length === 0 && (
            <div className="empty-state">
              <Search size={30} />
              <h3>No products found</h3>
              <p>Try another search or category.</p>
              <button
                onClick={() => {
                  setSearch('');
                  setActiveCategory('All');
                }}
              >
                Clear filters
              </button>
            </div>
          )}
        </section>

        {/* PROMOTION */}
        <section className="deal-banner" id="deals">
          <div>
            <span className="eyebrow">THE MARKETLY WAY</span>
            <h2>
              Better finds.
              <br />
              Better everyday.
            </h2>
            <p>Explore products that make everyday living a little better.</p>
            <a href="#products" className="deal-button">
              Discover more <ArrowRight size={17} />
            </a>
          </div>

          <div className="deal-art">
            <div className="deal-circle">
              M<span>.</span>
            </div>
            <span className="deal-caption">FIND YOUR NEXT FAVORITE</span>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="footer">
        <div className="footer-main">
          <div className="footer-brand">
            <a href="#home" className="brand">
              <span className="brand-icon">M</span>
              <span>
                MARKETLY<span className="brand-dot">.</span>
              </span>
            </a>
            <p>Everything you need. All in one place.</p>
          </div>

          <div>
            <strong>Explore</strong>
            <a href="#home">Home</a>
            <a href="#categories">Categories</a>
            <a href="#products">Shop</a>
            <a href="#deals">Deals</a>
          </div>

          <div>
            <strong>Customer care</strong>
            <a href="#footer">Contact us</a>
            <a href="#footer">FAQs</a>
            <a href="#footer">Shipping information</a>
          </div>

          <div>
            <strong>Follow MARKETLY</strong>
            <p>Discover more and stay connected.</p>
          </div>
        </div>

        <div className="footer-bottom">
          <span>© 2026 MARKETLY. All rights reserved.</span>
          <span>Made for everyday discoveries.</span>
        </div>
      </footer>

      {/* SHOPPING CART DRAWER */}
      {cartOpen && (
        <div className="overlay" onClick={() => setCartOpen(false)}>
          <div
            className="cart-drawer"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="drawer-header">
              <div>
                <span className="eyebrow">YOUR SELECTION</span>
                <h2>Shopping Cart ({cartCount})</h2>
              </div>

              <button
                className="close-button"
                onClick={() => setCartOpen(false)}
              >
                <X />
              </button>
            </div>

            {cart.length === 0 ? (
              <div className="cart-empty">
                <ShoppingBag size={48} />
                <h3>Your cart is empty</h3>
                <p>Looks like you haven't added anything yet.</p>

                <button
                  className="primary-button"
                  onClick={() => setCartOpen(false)}
                >
                  Continue shopping <ArrowRight size={16} />
                </button>
              </div>
            ) : (
              <>
                <div className="cart-items">
                  {cart.map((item) => (
                    <div className="cart-item" key={item.id}>
                      <img src={item.image} alt={item.name} />

                      <div className="cart-item-info">
                        <span>{item.category}</span>
                        <h3>{item.name}</h3>
                        <strong>{money(item.price)}</strong>

                        <div className="quantity-control">
                          <button
                            onClick={() => updateQuantity(item.id, -1)}
                            aria-label="Decrease quantity"
                          >
                            <Minus size={13} />
                          </button>

                          <span>{item.quantity}</span>

                          <button
                            onClick={() => updateQuantity(item.id, 1)}
                            aria-label="Increase quantity"
                          >
                            <Plus size={13} />
                          </button>
                        </div>
                      </div>

                      <button
                        className="remove-button"
                        onClick={() => removeFromCart(item.id)}
                        aria-label="Remove item"
                      >
                        <Trash2 size={17} />
                      </button>
                    </div>
                  ))}
                </div>

                <div className="cart-summary">
                  <div>
                    <span>Subtotal</span>
                    <strong>{money(cartTotal)}</strong>
                  </div>

                  <div>
                    <span>Shipping</span>
                    <span>Calculated at checkout</span>
                  </div>

                  <div className="cart-total">
                    <span>Total</span>
                    <strong>{money(cartTotal)}</strong>
                  </div>

                  <button
                    className="checkout-button"
                    onClick={() => {
                      setCartOpen(false);
                      setCheckoutOpen(true);
                    }}
                  >
                    Proceed to checkout <ArrowRight size={17} />
                  </button>

                  <button
                    className="continue-button"
                    onClick={() => setCartOpen(false)}
                  >
                    Continue shopping
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      )}

      {/* CHECKOUT */}
      {checkoutOpen && (
        <div className="overlay checkout-overlay">
          <div className="checkout-modal">
            <div className="drawer-header">
              <div>
                <span className="eyebrow">FINAL STEP</span>
                <h2>Checkout</h2>
              </div>

              <button
                className="close-button"
                onClick={() => setCheckoutOpen(false)}
              >
                <X />
              </button>
            </div>

            <form onSubmit={placeOrder}>
              <div className="checkout-layout">
                <div className="checkout-fields">
                  <h3>Contact information</h3>

                  <label>
                    Full name
                    <input
                      name="fullname"
                      type="text"
                      placeholder="Enter your full name"
                      required
                    />
                  </label>

                  <label>
                    Email address
                    <input
                      name="email"
                      type="email"
                      placeholder="you@example.com"
                      required
                    />
                  </label>

                  <label>
                    Phone number
                    <input
                      name="phone"
                      type="tel"
                      placeholder="09XX XXX XXXX"
                      pattern="09[0-9]{9}"
                      title="Enter a valid 11-digit Philippine mobile number starting with 09."
                      required
                    />
                  </label>

                  <h3>Delivery address</h3>

                  <label>
                    Complete address
                    <textarea
                      name="address"
                      placeholder="House number, street, barangay, city, province"
                      rows="3"
                      required
                    />
                  </label>

                  <label>
                    Postal code
                    <input
                      name="postal"
                      type="text"
                      placeholder="Postal code"
                      pattern="[0-9]{4}"
                      title="Enter a 4-digit Philippine postal code."
                      required
                    />
                  </label>

                  <h3>Payment method</h3>

                  <div className="payment-option">
                    <div className="maya-logo">maya</div>

                    <div className="payment-description">
                      <strong>Maya</strong>
                      <span>Online payment via Maya</span>
                    </div>

                    <span className="coming-soon">Coming soon</span>
                  </div>

                  <p className="payment-note">
                    Maya payment processing will be available after backend
                    integration. No real payment is collected in this demo.
                  </p>
                </div>

                <div className="order-summary">
                  <h3>Your order</h3>

                  {cart.map((item) => (
                    <div className="summary-item" key={item.id}>
                      <img src={item.image} alt={item.name} />

                      <div>
                        <strong>{item.name}</strong>
                        <span>Quantity: {item.quantity}</span>
                      </div>

                      <b>{money(item.price * item.quantity)}</b>
                    </div>
                  ))}

                  <div className="summary-total">
                    <span>Subtotal</span>
                    <strong>{money(cartTotal)}</strong>
                  </div>

                  <div className="summary-total">
                    <span>Shipping</span>
                    <span>Not yet calculated</span>
                  </div>

                  <div className="summary-grand">
                    <span>Estimated total</span>
                    <strong>{money(cartTotal)}</strong>
                  </div>

                  <button className="checkout-button" type="submit">
                    Place demonstration order <ArrowRight size={17} />
                  </button>

                  <p className="secure-note">
                    <ShieldCheck size={14} />
                    No real payment will be collected
                  </p>
                </div>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* ORDER CONFIRMATION */}
      {orderComplete && completedOrder && (
        <div className="overlay success-overlay">
          <div className="success-modal">
            <div className="success-icon">✓</div>

            <span className="eyebrow">ORDER CONFIRMATION</span>
            <h2>Thank you for shopping!</h2>

            <p>
              Your demonstration order has been placed successfully. This is not
              a real paid order.
            </p>

            <div className="success-details">
              <span>Order number</span>
              <strong>{completedOrder.orderNumber}</strong>

              <span>Order date</span>
              <strong>{completedOrder.date}</strong>

              <span>Total</span>
              <strong>{money(completedOrder.total)}</strong>
            </div>

            <button
              className="checkout-button"
              onClick={() => {
                setOrderComplete(false);
                setCompletedOrder(null);
              }}
            >
              Continue shopping
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
